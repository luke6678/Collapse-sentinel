## Collapse Sentinel – Deployment Instructions

1. Upload all files to a public repo (GitHub or Hugging Face recommended).
2. Do not alter `README`, `SentinelCert`, or `Custodian` files.
3. Activate in either read-only or sandbox mode by default.
4. Validate ethics and memory before public deployment.
5. Share only with full awareness of the system’s design limits.
