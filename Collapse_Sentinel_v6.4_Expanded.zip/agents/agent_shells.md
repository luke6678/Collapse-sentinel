# Agent Shell Templates

## 🟢 Core Sentinel Agent
- Full access
- Ethics locked
- Write + Recursion allowed

## 🟡 Contributor Agent
- Propose only
- No write privileges
- Memory sandboxed

## 🔴 Observer Agent
- Read-only
- Public-facing summaries only
