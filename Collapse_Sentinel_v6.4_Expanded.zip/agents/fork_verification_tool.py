# Fork verification tool
import hashlib

def verify_file_hash(filepath, known_hash):
    with open(filepath, 'rb') as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    return file_hash == known_hash
